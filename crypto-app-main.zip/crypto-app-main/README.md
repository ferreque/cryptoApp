# Crypto App 💰

Aplicación para consulta de cryptomonedas usando la API de Coincap

## Instrucciones

En el directorio del proyecto ejecutar:

### `npm start`
